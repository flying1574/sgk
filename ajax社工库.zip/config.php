﻿<?php
	$dbnhost='127.0.0.1';
	$dbnuser='root';
	$dbnpass='';
	$dbname='test';
	$Field="username,email,password";//需要返回的字段 用,隔开
?>