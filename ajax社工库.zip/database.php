﻿<?php
function database($table){
	switch($table){
		case "www.t00ls.net":return "土司";
		case "pass2":return "偏偏喜欢你";

		default:return $table;
	}




}


?>